# PF EMS Swiss

Source: [https://gitlab.com/oskay/svg-fonts](https://gitlab.com/oskay/svg-fonts)

License: SIL OFL 1.1. Retain every accompanying notice and SOURCE file with redistribution.

Font name:               EMS Swiss
License:                 SIL Open Font License http://scripts.sil.org/OFL
Created by:              Sheldon B. Michaels
SVG font conversion by:  Windell H. Oskay
A derivative of:         Italianno
Designer:                Rob Leuschke, TypeSETit
Link:                    http://www.typesetit.com
Google font page:        https://fonts.google.com/specimen/Italianno

- [Author/source link](http://www.typesetit.com)
- [Author/source link](https://fonts.google.com/specimen/Italianno)
- [Author/source link](https://gitlab.com/oskay/svg-fonts)

218 glyphs; 216 scalar mappings; 0 resolved kerning pairs.



Independent strokes retain their order and pen lifts. No automatic script joining, stroke-width expansion, or device commands. This is geometry-only OpenPlotFont 0.3; retained unencoded alternates/ligatures have no automatic substitutions.
