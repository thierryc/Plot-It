# PF Relief SingleLine SVG

Source: [https://github.com/isdat-type/Relief-SingleLine](https://github.com/isdat-type/Relief-SingleLine)

License: SIL OFL 1.1. Retain every accompanying notice and SOURCE file with redistribution.

Created by FontForge 20201107 at Fri Feb 14 11:47:47 2025
 By Tanguy Vanlaeys
Copyright 2021 The Relief SingleLine Project Authors (https://github.com/isdat-type/Relief-SingleLine)

- [Author/source link](https://github.com/isdat-type/Relief-SingleLine)

568 glyphs; 423 scalar mappings; 23419 resolved kerning pairs.



Independent strokes retain their order and pen lifts. No automatic script joining, stroke-width expansion, or device commands. This is geometry-only OpenPlotFont 0.3; retained unencoded alternates/ligatures have no automatic substitutions.
